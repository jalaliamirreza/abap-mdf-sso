# 🏢 SAP Payroll to SSO DBF Converter
# تبدیل‌کننده حقوق و دستمزد SAP به فرمت DBF سازمان تامین اجتماعی

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 🎯 ویژگی‌های کلیدی

- ✅ **تبدیل دوطرفه CSV ↔ DBF**
- ✅ **رابط گرافیکی کاربرپسند** (GUI با tkinter)
- ✅ **Iran System Encoding** (100% دقیق و تست شده)
- ✅ **پشتیبانی کامل از متن فارسی**
- ✅ **دو فایل: Header + Workers** (dskkar00.dbf + dskwor00.dbf)
- ✅ **محاسبه خودکار حق بیمه** (7%)
- ✅ **تطابق کامل با ساختار واقعی SSO**
- ✅ **ابزارهای CLI و GUI** برای تبدیل فایل‌ها

## 🚀 استفاده سریع (Quick Start)

### روش اول: رابط گرافیکی (GUI) - پیشنهادی

```bash
python tools/dbf_converter_gui.py
```

### روش دوم: خط فرمان (CLI)

**تبدیل CSV به DBF:**
```bash
python tools/csv_to_dbf_complete.py sample/header.csv sample/workers.csv \
    --workshop-id "1234567890" --year 3 --month 9 --output-dir output
```

**تبدیل DBF به CSV:**
```bash
python tools/dbf_to_csv.py sample/dskkar00.dbf -o output/header.csv --include-hex
python tools/dbf_to_csv.py sample/dskwor00.dbf -o output/workers.csv --include-hex
```

---

## 📁 ساختار پروژه

```
📁 abap-mdf-sso/
├── 📁 tools/              # ابزارهای تبدیل
│   ├── csv_to_dbf_complete.py   # تبدیل CSV → DBF (2 فایل)
│   ├── dbf_to_csv.py            # تبدیل DBF → CSV (تک فایل)
│   └── dbf_converter_gui.py     # رابط گرافیکی
├── 📁 src/
│   └── utils/
│       └── iran_system_encoding.py  # انکودر Iran System
├── 📁 sample/            # فایل‌های نمونه
│   ├── header.csv
│   ├── workers.csv
│   ├── dskkar00.dbf
│   └── dskwor00.dbf
└── 📁 docs/              # مستندات فنی
    ├── REAL_STRUCTURE_ANALYSIS.md
    └── ENCODING_VERIFIED.md
```

---

## 📝 توضیحات فارسی

این پروژه مجموعه‌ای از ابزارهای تبدیل فایل برای تولید **دیسکت بیمه سازمان تامین اجتماعی** ایران است.

### چه کاری انجام می‌دهد؟

این برنامه فایل‌های **CSV** حاوی اطلاعات حقوق و دستمزد پرسنل را به فرمت **DBF** (دی‌بیس) مورد نیاز سازمان تامین اجتماعی تبدیل می‌کند، و برعکس.

### امکانات

- ✅ **تبدیل CSV → DBF**: دو فایل CSV (header + workers) → دو فایل DBF (dskkar00 + dskwor00)
- ✅ **تبدیل DBF → CSV**: دو فایل DBF → دو فایل CSV با نمایش Hex برای متن فارسی
- ✅ **رابط گرافیکی**: نرم‌افزار GUI با پشتیبانی کامل از زبان فارسی
- ✅ **انکودینگ Iran System**: پیاده‌سازی کامل انکودینگ اختصاصی تامین اجتماعی
- ✅ **محاسبه خودکار**: محاسبه خودکار حق بیمه (7٪) و جمع‌های کلی
- ✅ **ساختار استاندارد**: تطابق 100٪ با ساختار واقعی فایل‌های SSO

### فیلدهای اصلی دیسکت بیمه

فایل DBF تامین اجتماعی شامل فیلدهای زیر است:

1. **شماره بیمه** (Insurance Number)
2. **کد ملی** (National ID)
3. **نام** (First Name)
4. **نام خانوادگی** (Last Name)
5. **نام پدر** (Father's Name)
6. **تاریخ تولد** (Birth Date)
7. **روزهای کارکرد** (Working Days)
8. **حقوق مبنا** (Base Salary)
9. **اضافه کار** (Overtime)
10. **مزایای مشمول** (Taxable Benefits)
11. **جمع مزایا** (Total Benefits)

### نحوه استفاده

#### گام 1️⃣: نصب وابستگی‌ها

```bash
pip install -r requirements.txt
```

#### گام 2️⃣: آماده‌سازی فایل‌های CSV

دو فایل CSV آماده کنید:

**header.csv** - اطلاعات کارگاه (یک ردیف):
```csv
DSK_ID,DSK_NAME,DSK_FARM,DSK_ADRS,DSK_KIND,DSK_LISTNO,DSK_DISC,...
1234567890,شرکت نمونه,علی احمدی,تهران - خیابان ولیعصر,1,LIST001,...
```

**workers.csv** - اطلاعات کارکنان (چند ردیف):
```csv
DSW_ID1,PER_NATCOD,DSW_FNAME,DSW_LNAME,DSW_DD,DSW_MAH,DSW_MASH,...
12345678,1234567890,علی,احمدی,30,8000000,9500000,...
```

نمونه فایل‌ها در پوشه `sample/` موجود است.

#### گام 3️⃣: اجرای برنامه

##### روش اول: GUI (پیشنهادی)

```bash
python tools/dbf_converter_gui.py
```

1. تب **CSV → DBF** را انتخاب کنید
2. فایل‌های header.csv و workers.csv را انتخاب کنید
3. کد کارگاه، سال و ماه را وارد کنید
4. روی دکمه "تبدیل به DBF" کلیک کنید

##### روش دوم: CLI

```bash
python tools/csv_to_dbf_complete.py sample/header.csv sample/workers.csv \
    --workshop-id "1234567890" \
    --year 3 \
    --month 9 \
    --output-dir output
```

### پیش‌نیازها

- Python 3.8+
- سیستم‌عامل: Windows / Linux / macOS
- وابستگی‌های Python (نصب خودکار از requirements.txt)

---

## 🔧 جزئیات فنی

### ساختار فایل‌های DBF

این پروژه دو فایل DBF تولید می‌کند:

1. **dskkar00.dbf** - فایل هدر (26 فیلد)
   - اطلاعات کارگاه
   - جمع کل‌های ماهانه
   - تعداد کل کارکنان

2. **dskwor00.dbf** - فایل کارکنان (31 فیلد)
   - اطلاعات شخصی هر کارمند
   - روزهای کارکرد
   - حقوق و مزایا
   - حق بیمه محاسبه شده

### انکودینگ Iran System

این پروژه از **Iran System Encoding** استفاده می‌کند - یک انکودینگ اختصاصی برای متن فارسی که توسط سازمان تامین اجتماعی استفاده می‌شود.

ویژگی‌ها:
- 4 گروه کاراکتر بر اساس موقعیت (مجرد، ابتدا، وسط، انتها)
- تبدیل از Unicode → Windows-1256 → Iran System
- دقت 100٪ تست شده با فایل‌های واقعی SSO

مستندات کامل: `/docs/ENCODING_VERIFIED.md`

### ساختار کامل فیلدها

مستندات کامل ساختار فایل‌ها: `/docs/REAL_STRUCTURE_ANALYSIS.md`

---

## 🧪 تست و آزمایش

### تست با فایل‌های نمونه

```bash
# تبدیل فایل‌های نمونه CSV به DBF
python tools/csv_to_dbf_complete.py sample/header.csv sample/workers.csv \
    --workshop-id "1234567890" --year 3 --month 9 --output-dir test_output

# بررسی فایل‌های تولید شده
python tools/inspect_dbf.py test_output/dskkar00.dbf
python tools/inspect_dbf.py test_output/dskwor00.dbf

# تبدیل برگشت به CSV
python tools/dbf_to_csv.py test_output/dskkar00.dbf -o test_output/header_verify.csv --include-hex
python tools/dbf_to_csv.py test_output/dskwor00.dbf -o test_output/workers_verify.csv --include-hex
```

### تست انکودینگ

```bash
# بررسی درستی انکودینگ فارسی
python -c "from src.utils.iran_system_encoding import IranSystemEncoder; \
    encoder = IranSystemEncoder(); \
    result = encoder.unicode_to_iran_system('علی'); \
    print(' '.join(f'{b:02x}' for b in result))"
# خروجی باید باشد: fc f3 e4
```

---

## 📦 ابزارهای موجود

### 1. csv_to_dbf_complete.py
تبدیل کامل دو فایل CSV به دو فایل DBF

**ورودی:**
- header.csv (اطلاعات کارگاه)
- workers.csv (اطلاعات کارکنان)

**خروجی:**
- dskkar00.dbf (فایل هدر)
- dskwor00.dbf (فایل کارکنان)

### 2. dbf_to_csv.py
تبدیل فایل DBF به CSV

**ویژگی‌ها:**
- نمایش Hex برای فیلدهای فارسی
- حفظ ساختار اصلی DBF

### 3. dbf_converter_gui.py
رابط گرافیکی کاربرپسند

**ویژگی‌ها:**
- دو تب: CSV→DBF و DBF→CSV
- لیبل‌های فارسی
- نمایش لاگ در زمان واقعی
- انتخاب فایل با دیالوگ

### 4. inspect_dbf.py
ابزار بازرسی و تحلیل فایل‌های DBF

**کاربرد:**
- مشاهده ساختار فایل
- نمایش رکوردها
- بررسی انکودینگ

---

## License

This project is proprietary software developed for specific client requirements.

## Support

For issues and questions, please contact the development team.

---

## نکات مهم

⚠️ **توجه**:
- اطمینان حاصل کنید که اطلاعات شماره بیمه و کد ملی صحیح است
- قبل از ارسال به سایت تامین اجتماعی، فایل DBF را با داده‌های نمونه تست کنید
- از نسخه پشتیبان قبل از اجرای برنامه تهیه کنید
- فرمت تاریخ باید شمسی (جلالی) باشد

## مراجع

- [سایت تامین اجتماعی](https://www.tamin.ir)
- SAP HCM Documentation
- dBase File Format Specification
