========================================
SSO DBF SYSTEM - OFFLINE DEPLOYMENT
========================================

This package contains EVERYTHING needed to deploy the SSO DBF system
on a customer server with NO INTERNET ACCESS.

CONTENTS:
---------
1. python_packages/     - All Python dependencies (.whl files)
2. project_files/       - Complete project code
   - sap_integration/   - ABAP and Python integration scripts
   - src/               - Core Python modules
   - tools/             - Utility scripts
3. scripts/             - Installation scripts
4. docs/                - Complete documentation

QUICK START:
------------
1. Copy this entire folder to customer server (USB/CD)

2. Run setup on server:
   cd sso_offline_deployment
   ./scripts/setup_on_server.sh

3. Install Python packages (NO INTERNET NEEDED):
   ./scripts/install_python_packages.sh

4. Follow docs/OFFLINE_DEPLOYMENT_COMPLETE.md for:
   - SAP SM69 configuration
   - ABAP program deployment
   - Testing procedures

FILE SIZES:
-----------
Python packages: ~50 MB
Project files:   ~5 MB
Total:           ~55 MB

SYSTEM REQUIREMENTS:
--------------------
- Python 3.8 or higher
- SAP NetWeaver (any version with ABAP)
- Linux/Unix OS on application server
- ~200 MB free disk space

For detailed instructions, see:
docs/OFFLINE_DEPLOYMENT_COMPLETE.md

========================================
