#!/bin/bash
echo "Installing Python packages from offline files..."
echo "This does NOT require internet connection"
echo ""

cd "$(dirname "$0")/../python_packages"
pip3 install --no-index --find-links=. \
    dbfread \
    pandas \
    openpyxl \
    xlrd \
    jdatetime \
    python-dateutil \
    numpy

echo ""
echo "✅ Installation complete!"
echo ""
echo "Verifying installation..."
python3 << 'VERIFY'
import sys
packages = ['dbfread', 'pandas', 'openpyxl', 'xlrd', 'jdatetime', 'dateutil', 'numpy']
print("\nInstalled packages:")
for pkg in packages:
    try:
        exec(f"import {pkg}")
        print(f"✓ {pkg}")
    except ImportError:
        print(f"✗ {pkg} - FAILED")
        sys.exit(1)
print("\n✅ All packages verified!")
VERIFY
