#!/bin/bash
# Run this on customer SAP server

echo "=========================================="
echo "Setting up SSO DBF System on SAP Server"
echo "=========================================="
echo ""

# Define installation directory
INSTALL_DIR="/usr/sap/scripts/sso_system"
WORK_DIR="/usr/sap/scripts/dbf_converter"

echo "Installation directory: $INSTALL_DIR"
echo "Working directory: $WORK_DIR"
echo ""

# Check if running as root or SAP user
if [ "$EUID" -ne 0 ]; then 
    echo "⚠️  Not running as root. Make sure you have permissions for /usr/sap/scripts/"
    read -p "Continue? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Create directories
echo "Creating directories..."
mkdir -p $INSTALL_DIR
mkdir -p $WORK_DIR/{tmp,output,logs}

# Copy project files
echo "Copying project files..."
cp -r project_files/* $INSTALL_DIR/

# Set permissions
echo "Setting permissions..."
chmod -R 755 $INSTALL_DIR
chmod -R 755 $WORK_DIR
find $INSTALL_DIR -name "*.py" -exec chmod +x {} \;

echo ""
echo "✅ File structure created!"
echo ""
echo "Directory structure:"
ls -la $INSTALL_DIR
echo ""
ls -la $WORK_DIR
echo ""

echo "=========================================="
echo "Next steps:"
echo "=========================================="
echo "1. Install Python packages:"
echo "   cd $(pwd)"
echo "   ./scripts/install_python_packages.sh"
echo ""
echo "2. Configure SAP SM69 commands (see docs)"
echo "3. Deploy ABAP programs via SE38"
echo "4. Test with sample data"
echo ""
