# 🔧 SSO DBF Conversion Tools
# ابزارهای تبدیل فایل DBF سازمان تامین اجتماعی

این ابزارها برای تبدیل دوطرفه بین CSV و DBF طراحی شده‌اند.

## 📥 CSV to DBF

تبدیل فایل CSV به فرمت DBF برای آپلود به سایت تامین اجتماعی.

### استفاده:

```bash
python csv_to_dbf.py workers.csv \
  --workshop-id "1234567890" \
  --year 3 \
  --month 9 \
  --output dskwor00.dbf
```

### فرمت CSV:

فایل CSV باید ستون‌های زیر را داشته باشد:

```csv
DSW_ID1,PER_NATCOD,DSW_FNAME,DSW_LNAME,DSW_DNAME,DSW_IDNO,...
49874664,3990106619,علی,احمدی,محمد,12345,...
```

**نکات مهم:**
- سطر اول: نام ستون‌ها
- متن‌های فارسی به صورت خودکار با Iran System encoding کدگذاری می‌شوند
- تاریخ‌ها باید به فرمت YYYYMMDD (شمسی) باشند
- فیلدهای عددی باید عدد باشند (بدون جداکننده هزارگان)

### فیلدهای فارسی:

این فیلدها به صورت خودکار encode می‌شوند:
- `DSW_FNAME` - نام
- `DSW_LNAME` - نام خانوادگی
- `DSW_DNAME` - نام پدر
- `DSW_IDPLC` - محل صدور
- `DSW_OCP` - شغل

---

## 📤 DBF to CSV

تبدیل فایل DBF به CSV برای مشاهده و ویرایش در Excel.

### استفاده:

```bash
# بدون hex (فقط فیلدهای عددی)
python dbf_to_csv.py dskwor00.dbf --output workers.csv

# با hex (شامل Persian hex bytes)
python dbf_to_csv.py dskwor00.dbf --output workers.csv --include-hex
```

### خروجی:

**بدون --include-hex:**
```csv
DSW_ID1,PER_NATCOD,DSW_FNAME,DSW_LNAME,DSW_DD,DSW_MAH,...
49874664,3990106619,,,30,128095062,...
```

**با --include-hex:**
```csv
DSW_ID1,PER_NATCOD,DSW_FNAME,DSW_FNAME_HEX,DSW_DD,...
49874664,3990106619,,fcf3e4,30,...
```

**توجه:** فیلدهای فارسی با Iran System encoding کدگذاری شده‌اند و قابل decode به Unicode نیستند. فقط می‌توانید hex bytes آنها را مشاهده کنید.

---

## 🔄 Workflow کامل

### 1️⃣ ایجاد DBF از Excel:

```bash
# 1. در Excel فایل CSV بسازید
# 2. تبدیل به DBF:
python csv_to_dbf.py workers.csv \
  --workshop-id "کد کارگاه" \
  --year 3 \
  --month 9 \
  --output dskwor00.dbf

# 3. فایل dskwor00.dbf آماده آپلود به سایت بیمه است
```

### 2️⃣ بررسی DBF موجود:

```bash
# تبدیل به CSV برای مشاهده
python dbf_to_csv.py dskwor00.dbf --output check.csv --include-hex

# مشاهده در Excel
libreoffice check.csv
```

### 3️⃣ ویرایش و ایجاد مجدد:

```bash
# 1. DBF را به CSV تبدیل کنید
python dbf_to_csv.py dskwor00.dbf --output workers.csv

# 2. در Excel ویرایش کنید
# 3. دوباره به DBF تبدیل کنید
python csv_to_dbf.py workers_edited.csv \
  --workshop-id "1234567890" \
  --year 3 \
  --month 9 \
  --output dskwor00_new.dbf
```

---

## 📋 ساختار فیلدهای DBF

### dskwor00.dbf (31 فیلد):

| فیلد | نوع | طول | توضیح |
|------|-----|------|-------|
| DSW_ID | C | 10 | شناسه کارگاه |
| DSW_YY | N | 2 | سال |
| DSW_MM | N | 2 | ماه |
| DSW_ID1 | C | 8 | **شماره بیمه (فقط 8 رقم!)** |
| DSW_FNAME | C | 20 | نام (Iran System encoding) |
| DSW_LNAME | C | 25 | نام خانوادگی (Iran System encoding) |
| DSW_DNAME | C | 20 | نام پدر (Iran System encoding) |
| DSW_BDATE | C | 8 | تاریخ تولد (YYYYMMDD شمسی) |
| DSW_DD | N | 2 | روز کارکرد |
| DSW_MAH | N | 12 | حقوق ماهانه (ریال) |
| DSW_MAZ | N | 12 | مزایا (ریال) |
| DSW_MASH | N | 12 | مشمول بیمه (ریال) |
| DSW_BIME | N | 12 | حق بیمه (7% مشمول) |
| PER_NATCOD | C | 10 | کد ملی |
| ... | ... | ... | ... |

**مهم:**
- `DSW_BIME` = `DSW_MASH` × 0.07 (7 درصد)
- تاریخ‌ها باید شمسی باشند (مثال: 14030915)
- شماره بیمه (`DSW_ID1`) فقط 8 کاراکتر است!

---

## 🧪 تست و بررسی

### بررسی encoding فارسی:

```bash
python ../src/utils/extract_raw_bytes.py dskwor00.dbf
```

این ابزار hex bytes فیلدهای فارسی را نمایش می‌دهد.

**مثال خروجی:**
```
رکورد #1:
DSW_FNAME:
  Hex:   fc f3 e4
  Bytes: [252, 243, 228]
```

### مقایسه با فایل اصلی:

```bash
# استخراج از فایل شما
python ../src/utils/extract_raw_bytes.py your_file.dbf > your_output.txt

# استخراج از فایل اصلی SSO
python ../src/utils/extract_raw_bytes.py original_sso.dbf > original_output.txt

# مقایسه
diff your_output.txt original_output.txt
```

---

## ⚙️ نیازمندی‌ها

```bash
pip install dbfread dbf
```

---

## 🎯 Iran System Encoding

این ابزارها از **Iran System encoding** استفاده می‌کنند که یک encoding خاص برای فایل‌های DBF سازمان تامین اجتماعی است.

**ویژگی‌ها:**
- Context-sensitive: هر حرف بسته به موقعیتش 4 شکل مختلف دارد
- یک‌طرفه: نمی‌توان decode کرد
- مطابق با کد C# از: https://github.com/amirfahmideh/InsuranceToDbf

**تست‌شده و تایید‌شده:**
- ✅ "علی" → `fc f3 e4` (تطابق 100%)
- ✅ "محمدحسین" → `f6 fe a8 9f a2 f5 9f f5`
- ✅ "احمدی" → `fc a2 f5 9f 90`

---

## 📞 پشتیبانی

برای مشکلات یا سوالات:
1. چک کنید که فرمت CSV درست است
2. تست کنید با فایل‌های نمونه
3. hex bytes را بررسی کنید

---

**نسخه:** 1.0
**تاریخ:** 1403/09/02
